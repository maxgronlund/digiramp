Given(/^digiramp is prepared$/) do
  backend_is_prepared
end

