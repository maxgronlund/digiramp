require 'test_helper'

class CommonWorkFilesHelperTest < ActionView::TestCase
end
