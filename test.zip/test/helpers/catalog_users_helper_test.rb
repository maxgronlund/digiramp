require 'test_helper'

class CatalogUsersHelperTest < ActionView::TestCase
end
