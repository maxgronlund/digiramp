require 'test_helper'

class AddCatalogAssetsHelperTest < ActionView::TestCase
end
