require 'test_helper'

class ImportBatchesHelperTest < ActionView::TestCase
end
