require 'test_helper'

class ActivityCounterHelperTest < ActionView::TestCase
end
