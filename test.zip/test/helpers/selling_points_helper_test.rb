require 'test_helper'

class SellingPointsHelperTest < ActionView::TestCase
end
