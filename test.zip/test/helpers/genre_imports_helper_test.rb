require 'test_helper'

class GenreImportsHelperTest < ActionView::TestCase
end
