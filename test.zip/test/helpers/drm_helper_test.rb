require 'test_helper'

class DrmHelperTest < ActionView::TestCase
end
