require 'test_helper'

class InvestorsHelperTest < ActionView::TestCase
end
