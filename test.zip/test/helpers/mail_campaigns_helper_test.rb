require 'test_helper'

class MailCampaignsHelperTest < ActionView::TestCase
end
