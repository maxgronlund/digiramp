require 'test_helper'

class OpportunitiesHelperTest < ActionView::TestCase
end
