require 'test_helper'

class AddSharedCatalogAssetsHelperTest < ActionView::TestCase
end
