require 'test_helper'

class MusicSubmissionsHelperTest < ActionView::TestCase
end
