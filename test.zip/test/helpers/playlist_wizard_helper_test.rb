require 'test_helper'

class PlaylistWizardHelperTest < ActionView::TestCase
end
