require 'test_helper'

class ExportRecordingsHelperTest < ActionView::TestCase
end
