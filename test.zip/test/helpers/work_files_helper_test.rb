require 'test_helper'

class WorkFilesHelperTest < ActionView::TestCase
end
