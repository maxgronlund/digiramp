require 'test_helper'

class AddRecordingHelperTest < ActionView::TestCase
end
