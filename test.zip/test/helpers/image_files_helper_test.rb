require 'test_helper'

class ImageFilesHelperTest < ActionView::TestCase
end
