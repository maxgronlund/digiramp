require 'test_helper'

class UserAccountsHelperTest < ActionView::TestCase
end
