require 'test_helper'

class LegalDocumentsHelperTest < ActionView::TestCase
end
