require 'test_helper'

class EngineRoomsHelperTest < ActionView::TestCase
end
