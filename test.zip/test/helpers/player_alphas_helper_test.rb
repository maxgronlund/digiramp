require 'test_helper'

class PlayerAlphasHelperTest < ActionView::TestCase
end
