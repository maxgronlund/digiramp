require 'test_helper'

class RecordingArtworksHelperTest < ActionView::TestCase
end
