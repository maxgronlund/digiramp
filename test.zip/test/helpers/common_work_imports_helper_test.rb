require 'test_helper'

class CommonWorkImportsHelperTest < ActionView::TestCase
end
