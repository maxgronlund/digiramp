require 'test_helper'

class AuthorizationProvidersHelperTest < ActionView::TestCase
end
