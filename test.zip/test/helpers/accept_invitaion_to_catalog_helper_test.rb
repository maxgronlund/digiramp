require 'test_helper'

class AcceptInvitaionToCatalogHelperTest < ActionView::TestCase
end
