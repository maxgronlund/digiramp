require 'test_helper'

class PromotionHelperTest < ActionView::TestCase
end
