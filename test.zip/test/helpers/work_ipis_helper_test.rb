require 'test_helper'

class WorkIpisHelperTest < ActionView::TestCase
end
