require 'test_helper'

class AddRecordingsHelperTest < ActionView::TestCase
end
