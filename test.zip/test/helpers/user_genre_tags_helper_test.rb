require 'test_helper'

class UserGenreTagsHelperTest < ActionView::TestCase
end
