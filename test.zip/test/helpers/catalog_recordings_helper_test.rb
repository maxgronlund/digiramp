require 'test_helper'

class CatalogRecordingsHelperTest < ActionView::TestCase
end
