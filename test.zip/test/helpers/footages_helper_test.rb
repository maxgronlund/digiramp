require 'test_helper'

class FootagesHelperTest < ActionView::TestCase
end
