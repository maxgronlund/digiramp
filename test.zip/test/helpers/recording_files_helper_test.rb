require 'test_helper'

class RecordingFilesHelperTest < ActionView::TestCase
end
