require 'test_helper'

class GenreTagsHelperTest < ActionView::TestCase
end
