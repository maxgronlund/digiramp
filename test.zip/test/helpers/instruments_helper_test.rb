require 'test_helper'

class InstrumentsHelperTest < ActionView::TestCase
end
