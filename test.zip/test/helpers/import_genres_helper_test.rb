require 'test_helper'

class ImportGenresHelperTest < ActionView::TestCase
end
