require 'test_helper'

class SharedAssetsHelperTest < ActionView::TestCase
end
