require 'test_helper'

class SubmitFromHelperTest < ActionView::TestCase
end
