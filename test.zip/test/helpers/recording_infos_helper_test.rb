require 'test_helper'

class RecordingInfosHelperTest < ActionView::TestCase
end
