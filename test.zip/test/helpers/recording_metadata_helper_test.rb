require 'test_helper'

class RecordingMetadataHelperTest < ActionView::TestCase
end
