require 'test_helper'

class EditClientsHelperTest < ActionView::TestCase
end
