require 'test_helper'

class DevelopmentLogHelperTest < ActionView::TestCase
end
