require 'test_helper'

class ClientGroupsHelperTest < ActionView::TestCase
end
