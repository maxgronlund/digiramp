require 'test_helper'

class UploadCatalogRecordingsHelperTest < ActionView::TestCase
end
