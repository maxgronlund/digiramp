require 'test_helper'

class VideoPostsHelperTest < ActionView::TestCase
end
