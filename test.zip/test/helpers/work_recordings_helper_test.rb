require 'test_helper'

class WorkRecordingsHelperTest < ActionView::TestCase
end
