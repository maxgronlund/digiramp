require 'test_helper'

class CommonWorkArtworksHelperTest < ActionView::TestCase
end
