require 'test_helper'

class OpportunityInvitationsHelperTest < ActionView::TestCase
end
