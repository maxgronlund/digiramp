require 'test_helper'

class WidgetThemesHelperTest < ActionView::TestCase
end
