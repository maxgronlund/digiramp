require 'test_helper'

class SignupHelperTest < ActionView::TestCase
end
