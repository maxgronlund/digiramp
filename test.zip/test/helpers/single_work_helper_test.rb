require 'test_helper'

class SingleWorkHelperTest < ActionView::TestCase
end
