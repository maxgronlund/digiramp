require 'test_helper'

class CustomerEventsHelperTest < ActionView::TestCase
end
