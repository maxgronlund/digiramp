require 'test_helper'

class AlbumsHelperTest < ActionView::TestCase
end
