require 'test_helper'

class FeatureRequestHelperTest < ActionView::TestCase
end
