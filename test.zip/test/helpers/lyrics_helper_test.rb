require 'test_helper'

class LyricsHelperTest < ActionView::TestCase
end
