require 'test_helper'

class EmbedHelperTest < ActionView::TestCase
end
