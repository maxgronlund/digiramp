require 'test_helper'

class CatalogWorksHelperTest < ActionView::TestCase
end
