require 'test_helper'

class SharedCommonWorkIpisHelperTest < ActionView::TestCase
end
