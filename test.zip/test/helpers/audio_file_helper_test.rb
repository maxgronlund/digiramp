require 'test_helper'

class AudioFileHelperTest < ActionView::TestCase
end
