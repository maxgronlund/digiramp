require 'test_helper'

class TermsAndConditionsHelperTest < ActionView::TestCase
end
