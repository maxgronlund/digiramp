require 'test_helper'

class SupportHelperTest < ActionView::TestCase
end
