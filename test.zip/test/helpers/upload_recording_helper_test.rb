require 'test_helper'

class UploadRecordingHelperTest < ActionView::TestCase
end
