require 'test_helper'

class CrmHelperTest < ActionView::TestCase
end
