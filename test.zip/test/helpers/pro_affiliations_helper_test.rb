require 'test_helper'

class ProAffiliationsHelperTest < ActionView::TestCase
end
