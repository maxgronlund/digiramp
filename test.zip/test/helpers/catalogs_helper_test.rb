require 'test_helper'

class CatalogsHelperTest < ActionView::TestCase
end
