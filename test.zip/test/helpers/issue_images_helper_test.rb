require 'test_helper'

class IssueImagesHelperTest < ActionView::TestCase
end
