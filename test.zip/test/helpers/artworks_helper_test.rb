require 'test_helper'

class ArtworksHelperTest < ActionView::TestCase
end
