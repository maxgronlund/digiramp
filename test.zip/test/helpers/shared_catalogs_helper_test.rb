require 'test_helper'

class SharedCatalogsHelperTest < ActionView::TestCase
end
