require 'test_helper'

class AccountWorksHelperTest < ActionView::TestCase
end
