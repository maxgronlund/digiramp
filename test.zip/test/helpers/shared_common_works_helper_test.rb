require 'test_helper'

class SharedCommonWorksHelperTest < ActionView::TestCase
end
