require 'test_helper'

class InviteProvidersHelperTest < ActionView::TestCase
end
