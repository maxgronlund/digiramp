require 'test_helper'

class ProjectTasksHelperTest < ActionView::TestCase
end
