require 'test_helper'

class AcceptInvitationsHelperTest < ActionView::TestCase
end
