require 'test_helper'

class CommonWorksHelperTest < ActionView::TestCase
end
