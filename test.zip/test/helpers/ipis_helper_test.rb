require 'test_helper'

class IpisHelperTest < ActionView::TestCase
end
