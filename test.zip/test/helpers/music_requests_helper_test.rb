require 'test_helper'

class MusicRequestsHelperTest < ActionView::TestCase
end
