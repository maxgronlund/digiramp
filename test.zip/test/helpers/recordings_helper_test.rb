require 'test_helper'

class RecordingsHelperTest < ActionView::TestCase
end
