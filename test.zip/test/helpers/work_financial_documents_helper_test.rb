require 'test_helper'

class WorkFinancialDocumentsHelperTest < ActionView::TestCase
end
