require 'test_helper'

class AddContentHelperTest < ActionView::TestCase
end
