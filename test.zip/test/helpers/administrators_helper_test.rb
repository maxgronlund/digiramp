require 'test_helper'

class AdministratorsHelperTest < ActionView::TestCase
end
