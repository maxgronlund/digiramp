require 'test_helper'

class RecordingBucketsHelperTest < ActionView::TestCase
end
