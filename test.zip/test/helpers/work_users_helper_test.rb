require 'test_helper'

class WorkUsersHelperTest < ActionView::TestCase
end
