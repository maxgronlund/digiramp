require 'test_helper'

class UserRecordingsHelperTest < ActionView::TestCase
end
