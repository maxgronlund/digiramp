require 'test_helper'

class SharedRecordingsHelperTest < ActionView::TestCase
end
