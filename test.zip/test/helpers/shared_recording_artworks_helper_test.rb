require 'test_helper'

class SharedRecordingArtworksHelperTest < ActionView::TestCase
end
