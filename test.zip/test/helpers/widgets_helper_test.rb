require 'test_helper'

class WidgetsHelperTest < ActionView::TestCase
end
