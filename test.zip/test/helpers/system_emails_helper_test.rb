require 'test_helper'

class SystemEmailsHelperTest < ActionView::TestCase
end
