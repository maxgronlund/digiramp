require 'test_helper'

class MoveRecordingsHelperTest < ActionView::TestCase
end
