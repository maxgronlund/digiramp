require 'test_helper'

class EmailHelperTest < ActionView::TestCase
end
