require 'test_helper'

class PrivatePlaylistsHelperTest < ActionView::TestCase
end
