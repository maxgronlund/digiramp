require 'test_helper'

class RecordingIpisHelperTest < ActionView::TestCase
end
