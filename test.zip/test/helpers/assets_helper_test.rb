require 'test_helper'

class AssetsHelperTest < ActionView::TestCase
end
