require 'test_helper'

class SelectArtworkFromHelperTest < ActionView::TestCase
end
