require 'test_helper'

class ClientImportsHelperTest < ActionView::TestCase
end
