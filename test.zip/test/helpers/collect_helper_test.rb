require 'test_helper'

class CollectHelperTest < ActionView::TestCase
end
