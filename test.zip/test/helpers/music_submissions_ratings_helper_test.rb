require 'test_helper'

class MusicSubmissionsRatingsHelperTest < ActionView::TestCase
end
