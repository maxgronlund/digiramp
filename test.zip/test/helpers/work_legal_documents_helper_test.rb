require 'test_helper'

class WorkLegalDocumentsHelperTest < ActionView::TestCase
end
