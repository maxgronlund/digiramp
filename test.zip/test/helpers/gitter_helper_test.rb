require 'test_helper'

class GitterHelperTest < ActionView::TestCase
end
