require 'test_helper'

class PlaylistRecordingsHelperTest < ActionView::TestCase
end
