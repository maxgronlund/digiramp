require 'test_helper'

class RecordingSelectCommonWorkHelperTest < ActionView::TestCase
end
