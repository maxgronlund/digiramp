require 'test_helper'

class PermissionsHelperTest < ActionView::TestCase
end
