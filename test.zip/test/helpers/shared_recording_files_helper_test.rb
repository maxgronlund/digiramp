require 'test_helper'

class SharedRecordingFilesHelperTest < ActionView::TestCase
end
