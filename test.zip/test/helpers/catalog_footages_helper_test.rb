require 'test_helper'

class CatalogFootagesHelperTest < ActionView::TestCase
end
