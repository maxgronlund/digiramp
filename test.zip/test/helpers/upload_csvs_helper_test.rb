require 'test_helper'

class UploadCsvsHelperTest < ActionView::TestCase
end
