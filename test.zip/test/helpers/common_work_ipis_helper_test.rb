require 'test_helper'

class CommonWorkIpisHelperTest < ActionView::TestCase
end
