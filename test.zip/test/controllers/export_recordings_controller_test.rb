require 'test_helper'

class ExportRecordingsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
