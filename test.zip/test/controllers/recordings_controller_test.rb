require 'test_helper'

class RecordingsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
