require 'test_helper'

class GenreImportTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
