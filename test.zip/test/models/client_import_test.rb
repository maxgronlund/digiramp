require 'test_helper'

class ClientImportTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
