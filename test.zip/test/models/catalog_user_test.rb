require 'test_helper'

class CatalogUserTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
