require 'test_helper'

class RecordingItemTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
