require 'test_helper'

class PlaylistKeyTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
