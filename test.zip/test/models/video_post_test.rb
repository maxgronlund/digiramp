require 'test_helper'

class VideoPostTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
