require 'test_helper'

class ClientGroupsPlaylistKeyUsersTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
