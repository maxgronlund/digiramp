require 'test_helper'

class RecordingIpiTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
