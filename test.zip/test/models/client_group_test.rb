require 'test_helper'

class ClientGroupTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
