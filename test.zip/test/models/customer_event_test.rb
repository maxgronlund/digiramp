require 'test_helper'

class CustomerEventTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
