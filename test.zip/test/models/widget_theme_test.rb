require 'test_helper'

class WidgetThemeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
