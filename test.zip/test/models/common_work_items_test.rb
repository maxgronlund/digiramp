require 'test_helper'

class CommonWorkItemsTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
