require 'test_helper'

class ImageFileTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
