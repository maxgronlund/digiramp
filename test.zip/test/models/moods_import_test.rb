require 'test_helper'

class MoodsImportTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
