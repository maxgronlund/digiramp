require 'test_helper'

class ImportBatchTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
