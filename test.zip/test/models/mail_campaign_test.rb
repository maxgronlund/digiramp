require 'test_helper'

class MailCampaignTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
