require 'test_helper'

class IpiCodeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
