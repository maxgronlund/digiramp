require 'test_helper'

class OpportunitiesUsersTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
