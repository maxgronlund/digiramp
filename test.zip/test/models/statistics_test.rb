require 'test_helper'

class StatisticsTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
