require 'test_helper'

class WorkUserTest < ActiveSupport::TestCase
  test "the truth" do
    assert false
  end
end
