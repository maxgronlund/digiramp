require 'test_helper'

class IssueImageTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
